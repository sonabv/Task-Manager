package com.sona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnixTaskManager1Application {

	public static void main(String[] args) {
		SpringApplication.run(UnixTaskManager1Application.class, args);
	}

}
