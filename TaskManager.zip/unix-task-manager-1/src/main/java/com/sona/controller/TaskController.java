package com.sona.controller;
import com.sona.model.Task;
import com.sona.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController


@RequestMapping("/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @GetMapping
    public List<Task> listTasks() {
        return taskService.getAllTasks();
    }

    @PostMapping
    public Task createTask(@RequestBody Task task) {
        return taskService.createTask(task);
    }

    @GetMapping("/{id}")
    public Task getTask(@PathVariable("id") String id) {
        return taskService.getTaskById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteTask(@PathVariable("id") String id) {
        taskService.deleteTask(id);
    }

    @PatchMapping("/{id}/status")
    public Task updateTaskStatus(@PathVariable("id") String id, @RequestBody Map<String, String> body) {
        String newStatus = body.get("status");
        return taskService.updateTaskStatus(id, newStatus);
    }
}