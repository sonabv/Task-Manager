package com.sona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnixTaskManager1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
